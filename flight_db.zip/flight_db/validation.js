function bookidValidation()
{

  var bookid = document.forms["myForm"]["bookid"].value;
    var letterNumber = /[0-9]{3}[A-Za-z]{5}/;
    if(bookid.match(letterNumber)) 
    {
       return true;
    }
    else{
      
      return false;
    }
  
 }

 function blankBookid(){
  var x = document.forms["myForm"]["bookid"].value;
  if (x == "") {
    
    return false;
  }
 }

 function validateForm() {
  if(blankBookid() == false){
    alert("Book-id must be filled out");
    return false;
  }
  else if(bookidValidation() == false){
    alert("wrong userid format");
    return false;
  }
}