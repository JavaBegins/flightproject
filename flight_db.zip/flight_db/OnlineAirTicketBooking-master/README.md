# Online Air Ticket Booking System

* An online airline ticket system using Java Spring MVC and Hibernate
* Build tool used - Apache Maven
* Database vendor used - MySQL
* All JavaMail functionality upcoming